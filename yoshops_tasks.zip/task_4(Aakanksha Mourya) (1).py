#!/usr/bin/env python
# coding: utf-8

# # Task 4

# ### 1. Creating a banner (JPG, PNG) for Yoshops data science training program

# In[5]:


# importing libraries
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[6]:


# opening up the image
img = Image.open('sample-1.jpg')
plt.imshow(img)


# In[7]:


# image object
final_img = img.copy()
draw = ImageDraw.Draw(final_img)

# setting the fonts
font1 = ImageFont.truetype('arial.ttf', 50)
font2 = ImageFont.truetype('arial.ttf', 20)

# adding text
draw.text((250,200),"Data Science", (0, 255, 0), font=font1, stroke_width=1)
draw.text((90,280),"Training & Internship Program",(0, 255, 0), font=font1, stroke_width=1)
draw.text((500,50),"Conatact:",(255, 0, 255), font=font2, stroke_width=1)
draw.text((500,70),"Website: https://yoshops.com/",(255, 255, 255), font=font2, stroke_width=1)
draw.text((500,90),"Email: info@yoshops.com",(255, 255, 255), font=font2, stroke_width=1)
draw.text((500,110),"Mobile: +91 9080749858",(255, 255, 255), font=font2, stroke_width=1)

# checking the image
plt.imshow(final_img)

# saving the image
final_img.save('data_science_training_program.jpg')
final_img.save('data_science_training_program.png')


#  ### 2. create a 20-sec short video on data science training program  

# In[8]:


import cv2
import moviepy.editor as mp
import os
import numpy as np


# In[9]:


height=1280
width=720
channel=3

fps=3
sec=20


# In[10]:


fourcc = cv2.VideoWriter_fourcc(*'MP42')
video = cv2.VideoWriter('test.mp4', fourcc, float(fps), (width, height))


# In[11]:


Files = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\SAMPLE IMAGES'


# In[12]:


img_list = os.listdir(Files)
img_list


# In[13]:


for frame_count in range(fps*sec):

    img_name=np.random.choice(img_list)
    img_path=os.path.join(Files,img_name)
    img=cv2.imread(img_path)
    img_resized=cv2.resize(img,(width,height))
    video.write(img_resized)
    
video.release()


# In[14]:


audio = mp.AudioFileClip("song.mp3")
video = mp.VideoFileClip("test.mp4")


# In[15]:


final = video.set_audio(audio)


# In[16]:


final.write_videofile("output.mp4")


# ### 3. write a blog on Yoshops data science training program

# #### -- sent a pdf of the same in the mega.io link 

# In[ ]:




