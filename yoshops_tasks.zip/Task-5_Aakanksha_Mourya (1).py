#!/usr/bin/env python
# coding: utf-8

# # Task 5

# ## 1. Python program to merge two files into one

# In[14]:


# importing libraries
import pandas as pd


# In[15]:


# fetching dataset-1
df1 = pd.read_csv('years_data.csv')
df1.head()


# In[16]:


# fetching dataset-2
df2 = pd.read_csv("tmin_data.csv")
df2.head()


# In[17]:


# merging the datasets
merged = pd.concat([df1, df2], axis=1)
merged.head()


# ## 2. Python program to sort files in different folders

# In[18]:


import os
import shutil


# In[19]:


# getting current directory path
print(os.getcwd())


# In[20]:


# changing diectory at a location
os.chdir(r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4')
new_dir=os.getcwd()
new_dir


# In[21]:


# getting details of a directory
os.listdir()


# In[22]:


for files in os.listdir():
    if files.endswith(".jpg"):
        #print (files)
        destination = r'C:\Users\Lenevo\Desktop\YOSHOPS\TASK 4\Master'
        shutil.move(files, destination)


# In[23]:


for files in os.listdir():
    if files.endswith(".png"):
        #print (files)
        destination = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\Master'
        shutil.move(files, destination)


# In[24]:


for files in os.listdir():
    if files.endswith(".PNG"):
        #print (files)
        destination = r'C:\Users\Levono\Desktop\YOSHOPS\TASK 4\Master'
        shutil.move(files, destination)


# In[25]:


word_files = os.path.join(new_dir, r'/word_file')


# In[26]:


# creating a new folder inside dir named as word 

destination = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\word'

# define the access rights
access_rights = 0o755

try:
    os.mkdir(destination, access_rights)
except OSError:
    print ("Creation of the directory %s failed" % destination)
else:
    print ("Successfully created the directory %s" % destination)


# In[27]:


# moving word files in new dir word
for files in os.listdir():
    if files.endswith(".docx"):
        #print (files)
        destination = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\word'
        shutil.move(files, destination)


# In[28]:


# creating multidirectories
# define the name of the directory to be created
path = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\word\python_file\pdf'

try:
    os.makedirs(path)
except OSError:
    print ("Creation of the directory %s failed" % path)
else:
    print ("Successfully created the directory %s" % path)


# In[29]:


# moving ipynb files to python directory

for files in os.listdir():
    if files.endswith(".ipynb"):
        #print (files)
        destination = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\word\python_file\python_file'
        shutil.move(files, destination)


# In[30]:


# moving pdf files to pdf directory

for files in os.listdir():
    if files.endswith(".pdf"):
        #print (files)
        destination = r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 4\word\python_file\pdf'
        shutil.move(files, destination)


# ## 3. Python program to separate duplicates in files

# In[31]:


# importing libraries
import os


# In[32]:


# fetching data
data = pd.read_csv(r'C:\Users\Lenovo\Desktop\YOSHOPS\TASK 5\movies_data.csv')
data.head()


# In[33]:


# getting duplicates
duplicates = data[data['Movie title'].duplicated()]
duplicates.head()


# In[34]:


# cheacking duplicates
duplicates.sort_values('Movie title', ignore_index=True).head(20)


# ## 4. Python program for sorting files by keywords

# In[35]:


# importing libraries
import os


# In[36]:


# defining a function to find files by keywords [filenames]
def file_finder(filename, search_path):
    result = []
    for root, dir, files in os.walk(search_path):
        if filename in files:
            result.append(os.path.join(root, filename))
    return result


# In[37]:


# applying the function to find 'sample-1.jpg'
file_finder('sample-1.jpg','C:\\Users\\Lenovo\\Desktop\\YOSHOPS\\TASK 4')


# In[38]:


# applying the function to find 'sample-4.jpg'
file_finder('sample-4.jpg','C:\\Users\\Lenovo\\Desktop\\YOSHOPS\\TASK 4')


# In[39]:


# defining a fuction to find files with different extentions [.jpg, .docs, .xlsx etc.]

root_dir = 'C:\\Users\\Lenovo\\Desktop\\YOSHOPS\\TASK 4'

for name in os.listdir(root_dir):
    if os.path.isdir(os.path.join(root_dir ,name)):
        for f in os.listdir(os.path.join(root_dir ,name)):
            if os.path.isfile(os.path.join(root_dir ,name, f)) and f.endswith('.jpg'):
                print(f)
                print(os.path.join(root_dir ,name, f))

