#!/usr/bin/env python
# coding: utf-8

# # Yoshops
# ## Data Science Internship 
# ## Task 7

# In[1]:


# making imports
import pandas as pd
import requests
from bs4 import BeautifulSoup


# In[2]:


# defining an URL to work on
coll_url = 'https://www.collegesearch.in/engineering-colleges-india'


# In[3]:


# creating objects for URL
req = requests.get(coll_url)
soup = BeautifulSoup(req.content,'html5lib')


# In[4]:


# getting colleges
college = soup.find_all('h2', class_='media-heading mg-0')
soup.find_all('h2', class_='media-heading mg-0')[0]


# In[5]:


# getting college details
details=soup.find_all('dl', class_='dl-horizontal mg-0')
soup.find_all('dl', class_='dl-horizontal mg-0')[0]


# In[6]:


# creating a df for the fetched data
data = pd.DataFrame({'clg':college,'details':details})


# In[7]:


# defining a function to fetch data from the URL
for i in range(1,50):
    coll_url='https://www.collegesearch.in/engineering-colleges-india'
    req=requests.get(coll_url)
    soup = BeautifulSoup(req.content,'html5lib')
    
    college=soup.find_all('h2', class_='media-heading mg-0')
    details=soup.find_all('dl', class_='dl-horizontal mg-0')
    
    df=pd.DataFrame({'clg':college,'details':details})
    data=data.append(df,ignore_index=True)


# In[8]:


# checking the shape of the df
data.shape


# In[9]:


# data preprocessing
data['college_name']=data['clg'].astype(str).str.split('\n',expand=True)[2].str.split('=',expand=True)[4]
data['city']=data['college_name'].astype(str).str.split(',',expand=True)[2].str.split('</a>',expand=True)[0]
data['Duration_years']=data['details'].astype(str).str.split('\n',expand=True)[4].str.split('Years',expand=True)[0].str.split('<dd>',expand=True)[1]
data['fees']=data['details'].astype(str).str.split('\n',expand=True)[7].str.split('<dd>',expand=True)[1].str.split('</dd>',expand=True)[0]
data['url']=data['clg'].astype(str).str.split('\n',expand=True)[2].str.split('=',expand=True)[1]


# In[10]:


# dropping the unnecessary columns
data.drop(columns=['clg','details'], axis=1, inplace=True)


# In[11]:


# storing the dataframe into an Excel file
data.to_excel('college_data.xlsx')


# ## On entering 1, show colleges from Delhi, Mumbai, Kolkata and Chennai

# In[12]:


Delhi = data[data['city'] == ' Delhi ']
Mumbai = data[data['city'] == ' Mumbai ']
Kolkata = data[data['city'] == ' Calicut ']
Chennai = data[data['city'] == ' Chennai ']


# In[13]:


Delhi


# In[14]:


# defining a function to achieve the same
def college_by_city(inp):
    if inp==1:
        print(Delhi['college_name'],Mumbai['college_name'],Kolkata['college_name'],Chennai['college_name'])
    else:
        pass


# In[15]:


# pressing 1
inp = int(input('Enter 1 to see colleges...'))
college_by_city(inp)


# ## On entering 2, show colleges in capital of states

# In[16]:


# defining a function to achieve the same
def college_by_capital(inp_1):
    if inp_1==2:
        print(Mumbai['college_name'],Kolkata['college_name'],Chennai['college_name'])
    else:
        pass


# In[17]:


#  pressing 2
inp_1 = int(input('Enter 2 to see colleges...'))
college_by_capital(inp_1)


# ## On entering 3, show all colleges

# In[18]:


# defining a fucntion to achieve the same
def all_college(inp_2):
    if inp_2==3:
        print(data['college_name'])
    else:
        pass


# In[19]:


# pressing 3
inp_2 = int(input('Enter 3 to see colleges...'))
all_college(inp_2)

