#!/usr/bin/env python
# coding: utf-8

# ## Task 6: Payroll ATS
# 1. Pay slips generate monthly one time
# 2. Cash flow report
# 3. Balance sheet report
# 4. Stack holder distribute (profit) report
# 

# In[1]:


# importing libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as num


# In[2]:


# loading the data
payslp = pd.read_excel('Kalyani_Balance_Sheet_November_2023.xlsx')
df = payslp.iloc[:, 0:6]
df.head()


# ## 1. payslips generator

# In[3]:


name_block = "Name of intern"
Department = 'Department'
foa = 'Fee of Aurangabad'
foc = 'Fee of Chennai'


# In[4]:


def name(n, d, a, c):
    print('*' * 58)
    print('\t\t\tYOOSHOP\t\t')
    print('\t\tDATA SCIENCE INTERNSHIP PAYSHIP')
    print('=' * 58)
    print('Branch Team Leader\t\t\t   kalyani Ghale')
    print('=' * 58)
    print(f"{name_block.upper()}\t\t\t\t{n}")
    print(f"{Department.upper()}\t\t\t\t{d}")
    print(f"{foa.upper()}\t\t\t\t{a}")
    print(f"{foc.upper()}\t\t\t\t\t{c}")
    print('=' * 58)
    print(f'SUBTOTAL\t\t\t\t\t{a + c}')
    print('\n')


# In[5]:


for i in df.values:
    name(i[0], i[2], i[5], i[4])


# ## 2. cash flow report

# In[6]:


Aurangabad = df['Aurangabad'].sum()
chennai = df['Chennai'].sum()
print('Total Cash Flow in Different cities:-')
a = int(input('Enter a number press 1 for chennai and 2 for Aurangabad :'))
if a == 1:
    print(f'\nTotal Cash Flow in Chennai: {chennai}')
elif a == 2:
    print(f'Total Cash Flow in Aurangabad: {Aurangabad}')
else:
    print('Invalid Selection')
print()


# ## 3. balance sheet report

# In[7]:


Aurangabad = df['Aurangabad'].sum()
chennai = df['Chennai'].sum()
print('Total Balance Sheet in Different cities:-')
a = int(input('Enter a number press 1 for chennai and 2 for Aurangabad :'))
if a == 1:
    print(f'\nTotal Balance Sheet in Chennai: {chennai}')
elif a == 2:
    print(f'Total Balance Sheet in Aurangabad: {Aurangabad}')
else:
    print('Invalid Selection')


# ## 4. stack holder distribute (profit) report

# In[8]:


labels = 'Aurangabad', 'chennai'
sizes = [Aurangabad, chennai]
explode = (0, 0.1)


# In[9]:


fig1, ax1 = plt.subplots()
colors = ['#F66F8D', '#FFB643']
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90, colors=colors)
plt.title('Stack holder profit ratio in different cities', fontsize=14)
ax1.axis('equal')
plt.show(); 

